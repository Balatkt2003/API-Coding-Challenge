// user.model.ts
export class User {
  uid!: number;
  username!: string;
  password!: string;
}
