
export class Book {
  isbn!: string;
  title!: string;
  author!: string;
  publicationYear!: number;
}
